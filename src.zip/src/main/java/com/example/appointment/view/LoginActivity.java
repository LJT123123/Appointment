package com.example.appointment.view;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.appointment.R;
import com.example.appointment.web.WebService;
import com.example.appointment.web.WebServicePost;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private SharedPreferences pref;
    private CheckBox rememberPass;
    private CheckBox autoLogin;
    private TextView register;
    private TextView forget_password;
    private Button login;
    private EditText usernameInputting;
    private EditText passwordInputting;
    // 创建等待框
    private ProgressDialog dialog;
    // 返回的数据
    private String info;
    // 返回主线程更新数据
    private static Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initView();
        initEvent();
    }

    private void initView(){
        autoLogin = findViewById(R.id.auto_login_checkbox_Login);
        register = findViewById(R.id.register_text_view_Login);
        forget_password = findViewById(R.id.forget_password_text_view_Login);
        login = findViewById(R.id.login_button_Login);
        usernameInputting = findViewById(R.id.username_edit_text_Login);
        passwordInputting = findViewById(R.id.password_edit_text_Login);
        rememberPass = findViewById(R.id.remember_password_checkbox_Login);
    }

    private void initEvent(){
        //实现记住密码和自动登录功能
        pref = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isRemember = pref.getBoolean("remember_password",false);
        boolean isAutoLogin = pref.getBoolean("auto_login",false);
        if(isAutoLogin){
            Intent intent = new Intent();
            intent.setClass(LoginActivity.this,MainActivity.class);
            startActivity(intent);
        }
        if(isRemember){
            String username = pref.getString("username","");
            String password = pref.getString("password","");
            usernameInputting.setText(username);
            passwordInputting.setText(password);
            rememberPass.setChecked(true);
        }

        login.setOnClickListener(this);
        register.setOnClickListener(this);
        forget_password.setOnClickListener(this);
    }

    @Override
    public void onClick(View view){

        Intent intent =new Intent();
        SharedPreferences.Editor editor = pref.edit();

        switch (view.getId()){
            case R.id.login_button_Login:
                if (!checkNetwork()) {
                    Toast toast = Toast.makeText(LoginActivity.this,"网络未连接", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    break;
                }
                dialog = new ProgressDialog(this);
                dialog.setTitle("提示");
                dialog.setMessage("正在登陆，请稍后...");
                dialog.setCancelable(false);
                dialog.show();

                String username = usernameInputting.getText().toString();
                String password = passwordInputting.getText().toString();
                // 创建子线程，分别进行Get和Post传输

                if (rememberPass.isChecked()){
                    editor.putBoolean("remember_password",true);
                    editor.putString("username",username);
                    editor.putString("password",password);
                }
                else editor.putBoolean("remember_password",false);
                if(autoLogin.isChecked()){
                    editor.putBoolean("auto_login",true);
                }
                else editor.putBoolean("auto_login",false);

                editor.putString("account",username);
                editor.apply();
                new Thread(new MyThread()).start();
                intent.setClass(LoginActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
                break;
            case R.id.register_text_view_Login:
                intent.setClass(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
                break;
            case R.id.forget_password_text_view_Login:
                intent.setClass(LoginActivity.this,FindPasswordActivity.class);
                startActivity(intent);
                break;
        }
    }


    // 子线程接收数据，主线程修改数据
    public class MyThread implements Runnable {
        @Override
        public void run() {
//            info = WebService.executeHttpGet(usernameInputting.getText().toString(), passwordInputting.getText().toString());
             info = WebServicePost.executeHttpPost(usernameInputting.getText().toString(), passwordInputting.getText().toString());
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Toast toast = Toast.makeText(LoginActivity.this,info, Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    dialog.dismiss();
                }
            });
        }
    }

    // 检测网络
    private boolean checkNetwork() {
        ConnectivityManager connManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connManager.getActiveNetworkInfo() != null) {
            return connManager.getActiveNetworkInfo().isAvailable();
        }
        return false;
    }
}
